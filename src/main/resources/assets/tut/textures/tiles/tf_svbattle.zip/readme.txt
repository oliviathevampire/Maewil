-=-=-=- -==-=- -==-=- -==-=- -==-=-
 TIME FANTASY
 SIDE-VIEW ANIMATED BATTLERS EXPANSION
-==-=- -==-=- -==-=- -==-=- -==-=-

Thank you for buying this asset pack!

Take your Time Fantasy characters into battle! This graphics pack expands on the characters from previous Time Fantasy sets with brand-new animations. 
Bring your combat to life with 80 animated battler sheets!

This is an expansion pack for the Time Fantasy RPG assets. 
The tiles in this pack will fit with all of my graphics in this style.

Note for RPG Maker MV users:

You'll find two images in the "system" folder. They both replace default images in your project's "system" folder:

- Shadow2.png is a blank image to overwrite the default shadow image. This is because the Time Fantasy style has the shadows as part of the sprite.
- States.png is a set of animations for status effects (poison, sleep, etc) that replace the default animations. These ones use pixel-art animation in the style of Time Fantasy so there won't be a style clash.

Thanks!


-------------------------
Time Fantasy Website
 timefantasy.net
-------------------------
Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues
Patreon
 patreon.com/finalbossblues
-------------------------

