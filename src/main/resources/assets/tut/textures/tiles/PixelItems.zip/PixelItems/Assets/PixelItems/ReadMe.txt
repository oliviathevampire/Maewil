PixelItems
art: benmhenry@gmail.com
code: davidahenry@gmail.com

Description:
Includes hundreds of 16 by 16 items, weapons, armor, and equipment sprites.

Documentation:
Files:
PixelItems/Sprite/Item.png : all in one, sprite sheet
PixelItems/Sprite/Item/Ammo.png (etc) : split, individual, duplicate, alternative, sprites
PixelItems/Item.unity : example scene
PixelItems/ReadMe.txt : this
